#include "mcc_generated_files/system/system.h"

uint16_t ms=0;
uint16_t sec=0;


void timer_callback(void)
{
    ms++;
    if (ms>1000) 
    {
        ms -= 1000;
        sec++;
        //IO_RD5_Toggle();
        //IO_RD6_Toggle();
        //IO_RD7_Toggle();
    }
}

uint8_t send_message(char * my_message){
    printf("%s",my_message);
    return 1;
}
        

#define BUFSIZE 4
#define MSGSIZE 64
#define TEAMSIZE 5
#define MSGTESTSIZE 64
#define MSGTESTCHAR 0


const char my_id='d';
const char team_ids[TEAMSIZE+1]="abcdX";
char buffer_in[BUFSIZE+1];
char message_in[MSGSIZE+1];
char message_out[MSGSIZE+1];


void fill_string(char * mystring,char value,unsigned int size){
    for (int ii=0;ii<size;ii++){
        mystring[ii]=value;
    }
}

unsigned int find_char(char * mystring, char value,unsigned int size){
    char c=0;
    for (int ii=0;ii<size;ii++){
        c= mystring[ii];
        if (c==value){
            return 1;
        }
    }
    return 0;
}

void handle_message(unsigned int ii){
    message_in[ii] = 0;
            char d=0;
        d = message_in[3]; //[#] position
        if (d == 'd'|| d == 'X'){
           
            
            //printf("PIC Frank  You Got Mail");
        } 
        else {
            send_message(message_in);
            return;   // exits handle message at this point
           }
        
        if (message_in[2]== 'a' || message_in[2]== 'b' || message_in[2]== 'c' ){ // if message is coming in from anyone
            uint8_t door =0;
          //  printf(" PIC Frank  This is from Alex");
            if (message_in[4] ==1)
            { 
                door = message_in[5];
                switch(door) 
                {
                    case 0:  //
                        IO_RD5_Toggle();
                       // printf("PIC Frank Value is 0\n");
                        break;
                    case 1:  // open
                        IO_RD5_Toggle();
                       // printf("PIC Frank  Value is 1\n");
                        break;
                    case 2: // close
                        IO_RD7_Toggle();
                        //printf("PIC Frank  Value is 2\n");.
                        break;

                    default: 
                       // printf("PIC Frank  value is outside expected");
                        break;
                } 
            }
        
        }
        else { 
            //printf(" the sender is not Alex");
        
                    
        }
        if (message_in[3] == 'X'){
            send_message(message_in);
            //printf("PIC Frank Broadcasting Message");
            
        }
        
       // if sender luis, open door x radians clock way, y radians counter clockwise
        // if sender alex, message_in[4] 
       
            
        
        
        }//end of the void
       
        
            
        //all work needs to be done above here
        
// nothing past this point   



int main(void)
{
    CHIPsel_SetLow();
    SPI1_Initialize();
    SPI1_Open(HOST_CONFIG);
    CHIPsel_SetHigh();
    
     uint8_t data[1];
    
    char c=0;
    unsigned int buffer_ii=0;
    unsigned int buffer_last_ii = 0;
    unsigned int message_ii=0;
    unsigned int message_last_ii=0;
    buffer_in[BUFSIZE]=0;
    message_in[MSGSIZE]=0;
    unsigned int message_incoming=0;
    fill_string(buffer_in,'a',BUFSIZE);
    fill_string(message_in,'_',MSGSIZE);
    message_in[MSGTESTSIZE]=MSGTESTCHAR;

    uint16_t ms_last=0;
    uint16_t sec_last=0;
    SYSTEM_Initialize();
    INTERRUPT_GlobalInterruptEnable(); 
    INTERRUPT_PeripheralInterruptEnable(); 
    Timer1_Initialize();
    Timer1_Start();
 
    TMR1_OverflowCallbackRegister(timer_callback);

    UART1_Initialize();
    while(1)
    {
         if(EUSART1_IsRxReady())
        {
            
            //printf("PIC Frank Entering RX");
            c= EUSART1_Read();
            //printf("%c",c);
            buffer_in[buffer_ii]=c;
            if (buffer_in[buffer_last_ii]=='A' & buffer_in[buffer_ii]=='Z'){
                fill_string(message_in,'_',MSGSIZE);
                message_in[MSGTESTSIZE]=MSGTESTCHAR;
                message_incoming=1;
                message_in[0] = buffer_in[buffer_last_ii];
                message_ii=1;
            }
            if (buffer_in[buffer_last_ii]=='Y' & buffer_in[buffer_ii]=='B'){
                message_incoming=0;
                message_in[message_ii] = buffer_in[buffer_ii];
                message_last_ii= message_ii;
                message_ii = message_ii+1;
                handle_message(message_ii);
            }
            if (message_incoming!=0){
                message_in[message_ii] = buffer_in[buffer_ii];

                if (message_ii==2){
                    unsigned result = 0;
                    char d=0;
                    d = message_in[message_ii];
                    result= find_char(team_ids,d,TEAMSIZE);
                    if (result==0){
//                        printf("PICf AZbaPIC: sender not in teamYB");
                        message_incoming=0;
                    } else {
                    }
                }

                if (message_ii==3){
                    unsigned result = 0;
                    char d=0;
                    d = message_in[message_ii];
                    result= find_char(team_ids,d,TEAMSIZE);
                    if (result==0){
//                        printf("PICf AZbaPIC: receiver not in teamYB");
                    } else {
                    }
                }
                
                message_last_ii= message_ii;
                message_ii = message_ii+1;
                
                if (message_ii<MSGTESTSIZE){} else{
//                    printf("PICf AZbaPIC: message too large. deleting YB");
                    message_incoming=0;
                    message_ii=0;
                }
            }
            buffer_last_ii= buffer_ii;
            buffer_ii = (buffer_ii+1)%BUFSIZE;
        }
        sec_last = sec;
        ms_last = ms;
        

    
    
//      
//        
//        CHIPsel_SetLow();
//        __delay_ms(10);
//        data[0] = 0b11101101;
//        SPI1_BufferExchange(data,1); //forward off, making other turn on
//        __delay_ms(10);
//        CHIPsel_SetHigh();
//        __delay_ms(200);
//        
    }
}